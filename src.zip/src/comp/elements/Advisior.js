import React from "react";

const Advisior = () => {
  return <div>Advisior</div>;
};

export default Advisior;
