import React from "react";

const Payroll = () => {
  return <div>Payroll</div>;
};

export default Payroll;
